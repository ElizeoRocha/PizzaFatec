 <div class="container2 ">

                  <div class="container">

                        <div class="row justify-content-sm-center">

                            <div class="col-sm-4  mt-3">

                                  <h3 class="h3white ml-3">Contato:</h3><br>

                                  <h6 class="ml-3"><i class="fab fa-whatsapp"></i> Whatsapp: (13)9548-4874</h6>
                                  <h6 class="ml-3"><i class="fas fa-phone"></i> Telefone: 3562-6542</h6>
                                  <h6 class="ml-3">CEP: 11700-100</h6>
                                  <h6 class="ml-3">Rua: Praça 15 de Janeiro - N°110, Boqueirão, Praia Grande</h6>


                            </div>

                            <div class="col-4 mt-3">

                            </div>

                            <div class="col-sm-4 mt-3">

                                  <h3 class="h3white text-center">Redes Social: </h3>

                                  <div class="btn-group-vertical btn-block btn-lg" id="socialbtn">

                                          <a class="btn1 btn mb-1" href="#"><i class="fab fa-facebook"></i> FaceBook</a>
                                          <a class="btn1 btn mb-1" href="#"><i class="fab fa-twitter"></i> Twitter</a>
                                          <a class="btn1 btn" href="#"><i class="fab fa-instagram"></i> Instagram</a>
                                          <br>
                                  </div>

                            </div>

                            <div class="col-12 text-center">
                                    <hr id="hr1">
                                    <p class="p2">ⓒ Pizzaria Fatec - PF</p>
                            </div>

                          </div>

                        </div>

                  </div>

                </div>

  </body>
</html>